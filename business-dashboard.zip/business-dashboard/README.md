# Ledger — Dynamic Business Dashboard

A live business analytics dashboard: revenue trend vs. target, category breakdown,
traffic sources, and a live order feed. Built with React (Vite) on the frontend
and an Express REST API on the backend, with an in-memory data store that mutates
every few seconds to simulate a real-time feed.

## Stack
- **Frontend:** React 18, Vite, Recharts, hand-written CSS (no UI framework)
- **Backend:** Node.js, Express, CORS
- **Data:** In-memory mock store (`server/data.js`) — swap this for a real DB/API later

## Run it locally

You'll need Node.js 18+ installed.

```bash
npm install

# Terminal 1 — start the API (port 4000)
npm run server

# Terminal 2 — start the frontend (port 5173)
npm run dev
```

Open http://localhost:5173. The ticker strip and orders table update automatically
every ~4 seconds as the backend mutates its data.

## What's real vs. mocked
- The REST API, polling, and React state management are fully real and reusable.
- The *data* is simulated in memory so the project runs standalone with zero setup.
  To make it genuinely live, point `server/data.js` at a real database (Postgres/
  MongoDB) or swap the polling in `App.jsx` for a WebSocket connection — the
  component structure won't need to change.

## Project structure
```
business-dashboard/
├── server/
│   ├── index.js       # Express app + REST routes
│   └── data.js         # Mock data store + tick() simulator
├── src/
│   ├── api/client.js    # fetch wrapper
│   ├── components/      # Sidebar, TickerStrip, charts, OrdersTable
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
└── vite.config.js       # proxies /api → localhost:4000
```

## Ideas to extend for interviews
- Add auth (JWT) and per-user dashboards
- Persist orders to Postgres, add a `/api/orders` POST endpoint
- Replace polling with a WebSocket (`ws` or Socket.IO) for true push updates
- Add date-range filtering on the revenue chart
- Write a couple of unit tests for `server/data.js`'s `tick()` logic
