import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Line, ComposedChart } from 'recharts'

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div className="chart-tooltip">
      <div className="chart-tooltip-label">{label}</div>
      {payload.map(p => (
        <div key={p.dataKey} className="chart-tooltip-row">
          <span className={`dot dot-${p.dataKey}`} />
          {p.name}: ${p.value.toLocaleString()}
        </div>
      ))}
    </div>
  )
}

export default function RevenueChart({ data }) {
  return (
    <div className="panel panel-wide">
      <div className="panel-header">
        <div>
          <h3>Revenue Trend</h3>
          <p className="panel-subtitle">Last 30 days vs. target</p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={260}>
        <ComposedChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
          <defs>
            <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#E8A33D" stopOpacity={0.35} />
              <stop offset="100%" stopColor="#E8A33D" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#232933" vertical={false} />
          <XAxis
            dataKey="date"
            tickFormatter={d => d.slice(5)}
            stroke="#8B94A3"
            tick={{ fontSize: 11, fontFamily: 'IBM Plex Mono' }}
            axisLine={{ stroke: '#232933' }}
            tickLine={false}
          />
          <YAxis
            stroke="#8B94A3"
            tick={{ fontSize: 11, fontFamily: 'IBM Plex Mono' }}
            axisLine={false}
            tickLine={false}
            tickFormatter={v => `$${Math.round(v / 1000)}k`}
          />
          <Tooltip content={<CustomTooltip />} />
          <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#E8A33D" strokeWidth={2} fill="url(#revFill)" />
          <Line type="monotone" dataKey="target" name="Target" stroke="#8B94A3" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  )
}
