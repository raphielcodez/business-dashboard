import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'

const COLORS = ['#E8A33D', '#D98C2B', '#C97719', '#B86A17', '#A65A14']

export default function CategoryChart({ data }) {
  const sorted = [...data].sort((a, b) => b.value - a.value)
  return (
    <div className="panel">
      <div className="panel-header">
        <div>
          <h3>Revenue by Category</h3>
          <p className="panel-subtitle">Current cycle</p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={240}>
        <BarChart data={sorted} layout="vertical" margin={{ top: 0, right: 16, left: 0, bottom: 0 }}>
          <XAxis type="number" hide />
          <YAxis
            type="category"
            dataKey="name"
            width={120}
            stroke="#8B94A3"
            tick={{ fontSize: 11, fontFamily: 'Space Grotesk' }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip
            cursor={{ fill: 'rgba(232,163,61,0.08)' }}
            contentStyle={{ background: '#161B22', border: '1px solid #232933', borderRadius: 8, fontFamily: 'IBM Plex Mono', fontSize: 12 }}
            formatter={v => [`$${v.toLocaleString()}`, 'Revenue']}
          />
          <Bar dataKey="value" radius={[0, 4, 4, 0]}>
            {sorted.map((entry, i) => (
              <Cell key={entry.name} fill={COLORS[i % COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
