const NAV = [
  { label: 'Overview', icon: '◆', active: true },
  { label: 'Revenue', icon: '▲' },
  { label: 'Orders', icon: '▤' },
  { label: 'Customers', icon: '◐' },
  { label: 'Reports', icon: '▥' },
  { label: 'Settings', icon: '◎' }
]

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <span className="brand-mark">L</span>
        <span className="brand-name">Ledger</span>
      </div>
      <nav className="sidebar-nav">
        {NAV.map(item => (
          <div key={item.label} className={`sidebar-item ${item.active ? 'is-active' : ''}`}>
            <span className="sidebar-icon" aria-hidden="true">{item.icon}</span>
            <span>{item.label}</span>
          </div>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="sidebar-user">
          <div className="avatar">OM</div>
          <div>
            <div className="user-name">Ops Manager</div>
            <div className="user-role">Operations</div>
          </div>
        </div>
      </div>
    </aside>
  )
}
