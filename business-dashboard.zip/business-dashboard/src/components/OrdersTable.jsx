function timeAgo(iso) {
  const diffMs = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diffMs / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  return `${hrs}h ago`
}

const STATUS_CLASS = {
  Fulfilled: 'status-fulfilled',
  Processing: 'status-processing',
  'Pending Review': 'status-pending'
}

export default function OrdersTable({ orders }) {
  return (
    <div className="panel panel-wide">
      <div className="panel-header">
        <div>
          <h3>Recent Orders</h3>
          <p className="panel-subtitle">Live feed — updates automatically</p>
        </div>
      </div>
      <div className="table-wrap">
        <table className="orders-table">
          <thead>
            <tr>
              <th>Order</th>
              <th>Customer</th>
              <th>Category</th>
              <th>Amount</th>
              <th>Status</th>
              <th>When</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(o => (
              <tr key={o.id}>
                <td className="mono">{o.id}</td>
                <td>{o.customer}</td>
                <td>{o.category}</td>
                <td className="mono">${o.amount.toLocaleString()}</td>
                <td>
                  <span className={`status-pill ${STATUS_CLASS[o.status]}`}>{o.status}</span>
                </td>
                <td className="mono muted">{timeAgo(o.timestamp)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
