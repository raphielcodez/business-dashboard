import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts'

const COLORS = ['#E8A33D', '#3FB950', '#58A6FF', '#BC8CFF', '#F85149']

export default function TrafficChart({ data }) {
  return (
    <div className="panel">
      <div className="panel-header">
        <div>
          <h3>Traffic Sources</h3>
          <p className="panel-subtitle">Share of visits, this week</p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={240}>
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            innerRadius={55}
            outerRadius={85}
            paddingAngle={3}
          >
            {data.map((entry, i) => (
              <Cell key={entry.name} fill={COLORS[i % COLORS.length]} stroke="none" />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{ background: '#161B22', border: '1px solid #232933', borderRadius: 8, fontFamily: 'IBM Plex Mono', fontSize: 12 }}
            formatter={v => [`${v}%`, 'Share']}
          />
          <Legend
            layout="vertical"
            align="right"
            verticalAlign="middle"
            iconType="circle"
            iconSize={8}
            wrapperStyle={{ fontSize: 12, fontFamily: 'Space Grotesk' }}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}
