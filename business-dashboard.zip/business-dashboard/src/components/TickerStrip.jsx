export default function TickerStrip({ overview, flash }) {
  const items = [
    { label: 'Revenue Today', value: `$${overview.revenueToday.toLocaleString()}`, delta: overview.revenueDelta, key: 'revenueToday' },
    { label: 'Active Users', value: overview.activeUsers.toLocaleString(), delta: overview.activeUsersDelta, key: 'activeUsers' },
    { label: 'Conversion', value: `${overview.conversionRate.toFixed(2)}%`, delta: overview.conversionDelta, key: 'conversionRate' },
    { label: 'Avg Order Value', value: `$${overview.avgOrderValue}`, delta: overview.avgOrderDelta, key: 'avgOrderValue' }
  ]

  return (
    <div className="ticker">
      {items.map(item => (
        <div key={item.key} className={`ticker-item ${flash[item.key] ? 'is-flashing' : ''}`}>
          <span className="ticker-label">{item.label}</span>
          <span className="ticker-value">{item.value}</span>
          <span className={`ticker-delta ${item.delta >= 0 ? 'is-up' : 'is-down'}`}>
            {item.delta >= 0 ? '▲' : '▼'} {Math.abs(item.delta).toFixed(1)}%
          </span>
        </div>
      ))}
      <div className="ticker-live">
        <span className="live-dot" />
        LIVE
      </div>
    </div>
  )
}
