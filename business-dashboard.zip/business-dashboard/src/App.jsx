import { useEffect, useRef, useState } from 'react'
import Sidebar from './components/Sidebar.jsx'
import TickerStrip from './components/TickerStrip.jsx'
import RevenueChart from './components/RevenueChart.jsx'
import CategoryChart from './components/CategoryChart.jsx'
import TrafficChart from './components/TrafficChart.jsx'
import OrdersTable from './components/OrdersTable.jsx'
import { fetchSnapshot } from './api/client.js'

export default function App() {
  const [snapshot, setSnapshot] = useState(null)
  const [flash, setFlash] = useState({})
  const [error, setError] = useState(null)
  const prevOverview = useRef(null)

  useEffect(() => {
    let cancelled = false
    let interval

    async function load() {
      try {
        const data = await fetchSnapshot()
        if (cancelled) return

        if (prevOverview.current) {
          const changed = {}
          for (const key of Object.keys(data.overview)) {
            if (prevOverview.current[key] !== data.overview[key]) changed[key] = true
          }
          setFlash(changed)
          setTimeout(() => setFlash({}), 700)
        }
        prevOverview.current = data.overview
        setSnapshot(data)
        setError(null)
      } catch (err) {
        setError('Could not reach the API. Is the server running on port 4000?')
      }
    }

    load()
    interval = setInterval(load, 4000)
    return () => {
      cancelled = true
      clearInterval(interval)
    }
  }, [])

  return (
    <div className="app-shell">
      <Sidebar />
      <main className="main">
        <header className="main-header">
          <div>
            <h1>Overview</h1>
            <p className="main-subtitle">Real-time snapshot of business performance</p>
          </div>
        </header>

        {error && <div className="banner-error">{error}</div>}

        {snapshot ? (
          <>
            <TickerStrip overview={snapshot.overview} flash={flash} />
            <div className="grid-row">
              <RevenueChart data={snapshot.revenueHistory} />
            </div>
            <div className="grid-row grid-split">
              <CategoryChart data={snapshot.categories} />
              <TrafficChart data={snapshot.traffic} />
            </div>
            <div className="grid-row">
              <OrdersTable orders={snapshot.orders} />
            </div>
          </>
        ) : (
          !error && <div className="loading">Loading dashboard…</div>
        )}
      </main>
    </div>
  )
}
