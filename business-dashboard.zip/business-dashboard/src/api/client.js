const BASE = '/api'

export async function fetchSnapshot() {
  const res = await fetch(`${BASE}/snapshot`)
  if (!res.ok) throw new Error('Failed to fetch snapshot')
  return res.json()
}
