import express from 'express'
import cors from 'cors'
import { store, tick } from './data.js'

const app = express()
const PORT = process.env.PORT || 4000

app.use(cors())
app.use(express.json())

// Advance the simulated business feed every 4 seconds.
setInterval(tick, 4000)

app.get('/api/overview', (req, res) => {
  res.json(store.overview)
})

app.get('/api/revenue', (req, res) => {
  res.json(store.revenueHistory)
})

app.get('/api/categories', (req, res) => {
  res.json(store.categories)
})

app.get('/api/traffic', (req, res) => {
  res.json(store.traffic)
})

app.get('/api/orders', (req, res) => {
  res.json(store.orders)
})

// Single combined endpoint so the client can refresh everything in one round trip.
app.get('/api/snapshot', (req, res) => {
  res.json({
    overview: store.overview,
    revenueHistory: store.revenueHistory,
    categories: store.categories,
    traffic: store.traffic,
    orders: store.orders
  })
})

app.listen(PORT, () => {
  console.log(`Dashboard API listening on http://localhost:${PORT}`)
})
