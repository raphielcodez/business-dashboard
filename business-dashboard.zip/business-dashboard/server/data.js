// In-memory mock data store that mutates over time to simulate a live business feed.

const CATEGORIES = ['Hardware', 'Software Licenses', 'Consulting', 'Support Plans', 'Training']
const SOURCES = ['Organic Search', 'Referral', 'Direct', 'Paid Ads', 'Social']
const CUSTOMERS = [
  'Marlowe Fenwick', 'Tanya Osei', 'Devon Blackwood', 'Priya Ramnarine', 'Elias Whitfield',
  'Simone Chevallier', 'Kwame Bartholomew', 'Ines Falcao', 'Aria Nakashima', 'Rohan Malhotra'
]

function randomBetween(min, max) {
  return Math.random() * (max - min) + min
}

function seedRevenueHistory() {
  const days = 30
  const history = []
  let base = 18000
  const now = new Date()
  for (let i = days - 1; i >= 0; i--) {
    base += randomBetween(-1200, 1800)
    base = Math.max(base, 9000)
    const d = new Date(now)
    d.setDate(d.getDate() - i)
    history.push({
      date: d.toISOString().slice(0, 10),
      revenue: Math.round(base),
      target: Math.round(19500 + i * 15)
    })
  }
  return history
}

function seedOrders() {
  const orders = []
  for (let i = 0; i < 8; i++) {
    orders.push(makeOrder(i))
  }
  return orders
}

let orderCounter = 1000
function makeOrder(offsetMinutes = 0) {
  orderCounter += 1
  const amount = Math.round(randomBetween(45, 2400))
  const statuses = ['Fulfilled', 'Processing', 'Pending Review']
  const timestamp = new Date(Date.now() - offsetMinutes * 60000)
  return {
    id: `ORD-${orderCounter}`,
    customer: CUSTOMERS[Math.floor(Math.random() * CUSTOMERS.length)],
    category: CATEGORIES[Math.floor(Math.random() * CATEGORIES.length)],
    amount,
    status: statuses[Math.floor(Math.random() * statuses.length)],
    timestamp: timestamp.toISOString()
  }
}

export const store = {
  revenueHistory: seedRevenueHistory(),
  orders: seedOrders(),
  categories: CATEGORIES.map(name => ({
    name,
    value: Math.round(randomBetween(4000, 22000))
  })),
  traffic: SOURCES.map(name => ({
    name,
    value: Math.round(randomBetween(8, 38))
  })),
  overview: {
    revenueToday: 8420,
    revenueDelta: 4.2,
    activeUsers: 1284,
    activeUsersDelta: 1.8,
    conversionRate: 3.4,
    conversionDelta: -0.3,
    avgOrderValue: 186,
    avgOrderDelta: 2.1
  }
}

// Simulate a live feed: nudge numbers, occasionally push a new order.
export function tick() {
  const last = store.revenueHistory[store.revenueHistory.length - 1]
  last.revenue = Math.max(9000, Math.round(last.revenue + randomBetween(-300, 450)))

  store.overview.revenueToday = Math.max(0, Math.round(store.overview.revenueToday + randomBetween(-150, 300)))
  store.overview.revenueDelta = Number((store.overview.revenueDelta + randomBetween(-0.4, 0.4)).toFixed(1))
  store.overview.activeUsers = Math.max(0, Math.round(store.overview.activeUsers + randomBetween(-15, 25)))
  store.overview.conversionRate = Number(Math.max(0, store.overview.conversionRate + randomBetween(-0.15, 0.15)).toFixed(2))
  store.overview.avgOrderValue = Math.max(0, Math.round(store.overview.avgOrderValue + randomBetween(-4, 6)))

  store.categories.forEach(c => {
    c.value = Math.max(500, Math.round(c.value + randomBetween(-600, 900)))
  })

  if (Math.random() < 0.35) {
    store.orders.unshift(makeOrder(0))
    store.orders = store.orders.slice(0, 12)
  }
}
